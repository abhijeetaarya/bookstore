<?php

/* twig/blog/latest.twig */
class __TwigTemplate_75ed72026e2834d15186352345a2d0ae6d6b96e23cf941113fa1b4c25fd79c1c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"bks-blog\">
    <div class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>";
        // line 4
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("Latest news", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
        echo "</h1>
            ";
        // line 5
        if (((isset($context["news_url"]) || array_key_exists("news_url", $context)) &&  !twig_test_empty(($context["news_url"] ?? null)))) {
            // line 6
            echo "                <a href=\"";
            echo twig_escape_filter($this->env, ($context["news_url"] ?? null), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("All Articles", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
            echo "\" class=\"bks-link\">";
            echo twig_escape_filter($this->env, sprintf("> %s", call_user_func_array($this->env->getFunction('__')->getCallable(), array("All Articles", twig_constant("THEME_TEXTDOMAIN")))), "html", null, true);
            echo "</a>
            ";
        }
        // line 8
        echo "        </div>
        ";
        // line 9
        if ((isset($context["latest_articles"]) || array_key_exists("latest_articles", $context))) {
            // line 10
            echo "            <div class=\"bks-blog-latest\">
                <ul>
                    ";
            // line 12
            $context["modulo"] = 2;
            // line 13
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["latest_articles"] ?? null));
            foreach ($context['_seq'] as $context["i"] => $context["post"]) {
                // line 14
                echo "                        ";
                if ((1 == ($context["i"] % ($context["modulo"] ?? null)))) {
                    // line 15
                    echo "                            <li class=\"last\">
                        ";
                } else {
                    // line 17
                    echo "                            <li>
                        ";
                }
                // line 19
                echo "                            <article class=\"blog-article\">
                                <h5>";
                // line 20
                echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "get_post_time", array(0 => "j F Y", 1 => true, 2 => $this->getAttribute($context["post"], "ID", array())), "method"), "html", null, true);
                echo "</h5>
                                <h2>";
                // line 21
                echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "post_title", array()), "html", null, true);
                echo "</h2>
                                ";
                // line 22
                if ( !twig_test_empty($this->getAttribute($context["post"], "post_excerpt", array()))) {
                    // line 23
                    echo "                                    <p>";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "post_excerpt", array()), "html", null, true);
                    echo "</p>
                                ";
                } else {
                    // line 25
                    echo "                                    <p>";
                    echo $this->getAttribute(($context["fn"] ?? null), "wp_trim_words", array(0 => $this->getAttribute($context["post"], "post_content", array()), 1 => 10), "method");
                    echo "</p>
                                ";
                }
                // line 27
                echo "                                <div class=\"link-box\">
                                    <a href=\"";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "get_permalink", array(0 => $this->getAttribute($context["post"], "ID", array())), "method"), "html", null, true);
                echo "\" class=\"tiny-button yellow\" title=\"";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("Read more", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("Read more", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
                echo "</a>
                                </div>
                            </article>
                        </li>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['post'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            echo "                </ul>
            </div>
        ";
        }
        // line 36
        echo "    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "twig/blog/latest.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 36,  110 => 33,  95 => 28,  92 => 27,  86 => 25,  80 => 23,  78 => 22,  74 => 21,  70 => 20,  67 => 19,  63 => 17,  59 => 15,  56 => 14,  51 => 13,  49 => 12,  45 => 10,  43 => 9,  40 => 8,  30 => 6,  28 => 5,  24 => 4,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"bks-blog\">
    <div class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>{{ __(\"Latest news\", constant('THEME_TEXTDOMAIN')) }}</h1>
            {% if news_url is defined and news_url is not empty %}
                <a href=\"{{ news_url }}\" title=\"{{ __(\"All Articles\", constant('THEME_TEXTDOMAIN')) }}\" class=\"bks-link\">{{ '> %s'|format(__(\"All Articles\", constant('THEME_TEXTDOMAIN'))) }}</a>
            {% endif %}
        </div>
        {% if latest_articles is defined %}
            <div class=\"bks-blog-latest\">
                <ul>
                    {% set modulo = 2 %}
                    {% for i, post in latest_articles %}
                        {% if 1 == i % modulo %}
                            <li class=\"last\">
                        {% else %}
                            <li>
                        {% endif %}
                            <article class=\"blog-article\">
                                <h5>{{ fn.get_post_time('j F Y', true, post.ID) }}</h5>
                                <h2>{{ post.post_title }}</h2>
                                {% if post.post_excerpt is not empty %}
                                    <p>{{ post.post_excerpt }}</p>
                                {% else %}
                                    <p>{{ fn.wp_trim_words(post.post_content, 10)|raw }}</p>
                                {% endif %}
                                <div class=\"link-box\">
                                    <a href=\"{{ fn.get_permalink(post.ID) }}\" class=\"tiny-button yellow\" title=\"{{ __(\"Read more\", constant('THEME_TEXTDOMAIN')) }}\">{{ __(\"Read more\", constant('THEME_TEXTDOMAIN')) }}</a>
                                </div>
                            </article>
                        </li>
                    {% endfor %}
                </ul>
            </div>
        {% endif %}
    </div>
</div>", "twig/blog/latest.twig", "D:\\xampp\\htdocs\\bookstore\\htdocs\\content\\themes\\bookstore\\resources\\views\\twig\\blog\\latest.twig");
    }
}
