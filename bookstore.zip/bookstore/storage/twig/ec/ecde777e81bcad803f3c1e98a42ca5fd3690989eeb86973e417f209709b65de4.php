<?php

/* twig\pages\help.twig */
class __TwigTemplate_c972651b93bf03bf86534af62aad5322c1bf5debcf3fabec22ac4d4312f05381 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("twig/layouts/main.twig", "twig\\pages\\help.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "twig/layouts/main.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "    <div id=\"help\" class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute(($context["page"] ?? null), "post_title", array()), "html", null, true);
        echo "</h1>
        </div>
        ";
        // line 8
        if ( !twig_test_empty($this->getAttribute(($context["page"] ?? null), "post_content", array()))) {
            // line 9
            echo "            <div id=\"help--info\">
                <div id=\"help--info__wrapper\">
                    <p><span class=\"bubble-icon\"></span>";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute(($context["page"] ?? null), "post_content", array()), "html", null, true);
            echo "</p>
                </div>
            </div>
        ";
        }
        // line 15
        echo "        <div id=\"help--faqs\">
            <dl>
                ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["faqs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["faq"]) {
            // line 18
            echo "                    <dt>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["faq"], "post_title", array()), "html", null, true);
            echo "</dt>
                    <dd>";
            // line 19
            echo call_user_func_array($this->env->getFunction('wpautop')->getCallable(), array($this->getAttribute($context["faq"], "post_content", array())));
            echo "</dd>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['faq'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "            </dl>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "twig\\pages\\help.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 21,  66 => 19,  61 => 18,  57 => 17,  53 => 15,  46 => 11,  42 => 9,  40 => 8,  35 => 6,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'twig/layouts/main.twig' %}

{% block main %}
    <div id=\"help\" class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>{{ page.post_title }}</h1>
        </div>
        {% if page.post_content is not empty %}
            <div id=\"help--info\">
                <div id=\"help--info__wrapper\">
                    <p><span class=\"bubble-icon\"></span>{{ page.post_content }}</p>
                </div>
            </div>
        {% endif %}
        <div id=\"help--faqs\">
            <dl>
                {% for faq in faqs %}
                    <dt>{{ faq.post_title }}</dt>
                    <dd>{{ wpautop(faq.post_content)|raw }}</dd>
                {% endfor %}
            </dl>
        </div>
    </div>
{% endblock %}", "twig\\pages\\help.twig", "D:\\xampp\\htdocs\\bookstore\\htdocs\\content\\themes\\bookstore\\resources\\views\\twig\\pages\\help.twig");
    }
}
