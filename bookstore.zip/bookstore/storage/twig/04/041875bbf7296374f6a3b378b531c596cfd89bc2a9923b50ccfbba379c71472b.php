<?php

/* twig\pages\about.twig */
class __TwigTemplate_2b134285ca1e3b24e2054681fc4fca203a0a5eaf59ddaf977c0573458c88c2e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("twig/layouts/main.twig", "twig\\pages\\about.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "twig/layouts/main.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
    <div id=\"about\" class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute(($context["page"] ?? null), "post_title", array()), "html", null, true);
        echo "</h1>
        </div>
        <div id=\"about--content\">
            ";
        // line 10
        echo call_user_func_array($this->env->getFunction('wpautop')->getCallable(), array($this->getAttribute(($context["page"] ?? null), "post_content", array())));
        echo "
        </div>
        ";
        // line 12
        if ( !twig_test_empty(($context["members"] ?? null))) {
            // line 13
            echo "            <div id=\"about--team\">
                <ul>
                    ";
            // line 15
            $context["modulo"] = 3;
            // line 16
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["members"] ?? null));
            foreach ($context['_seq'] as $context["i"] => $context["member"]) {
                // line 17
                echo "                    ";
                if ( !($context["i"] % ($context["modulo"] ?? null))) {
                    // line 18
                    echo "                        <li class=\"last\">
                    ";
                } else {
                    // line 20
                    echo "                        <li>
                    ";
                }
                // line 22
                echo "                            <div class=\"member clearfix\">
                                <div class=\"member--picture\">
                                    ";
                // line 24
                echo $this->getAttribute(($context["fn"] ?? null), "wp_get_attachment_image", array(0 => $this->getAttribute($context["member"], "pic", array()), 1 => "member-pic"), "method");
                echo "
                                </div>
                                <div class=\"member--bio\">
                                    <h4>";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($context["member"], "full_name", array()), "html", null, true);
                echo "</h4>
                                    <p>";
                // line 28
                echo twig_escape_filter($this->env, $this->getAttribute($context["member"], "job", array()), "html", null, true);
                echo "</p>
                                </div>
                            </div>
                        </li>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['member'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            echo "                </ul>
            </div>
        ";
        }
        // line 36
        echo "    </div>

    <!-- Blog -->
    ";
        // line 39
        $this->loadTemplate("twig/blog/latest.twig", "twig\\pages\\about.twig", 39)->display($context);
        // line 40
        echo "    <!-- End blog -->

";
    }

    public function getTemplateName()
    {
        return "twig\\pages\\about.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 40,  106 => 39,  101 => 36,  96 => 33,  85 => 28,  81 => 27,  75 => 24,  71 => 22,  67 => 20,  63 => 18,  60 => 17,  55 => 16,  53 => 15,  49 => 13,  47 => 12,  42 => 10,  36 => 7,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'twig/layouts/main.twig' %}

{% block main %}

    <div id=\"about\" class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>{{ page.post_title }}</h1>
        </div>
        <div id=\"about--content\">
            {{ wpautop(page.post_content)|raw }}
        </div>
        {% if members is not empty %}
            <div id=\"about--team\">
                <ul>
                    {% set modulo = 3 %}
                    {% for i, member in members %}
                    {% if not i % modulo %}
                        <li class=\"last\">
                    {% else %}
                        <li>
                    {% endif %}
                            <div class=\"member clearfix\">
                                <div class=\"member--picture\">
                                    {{ fn.wp_get_attachment_image(member.pic, 'member-pic')|raw }}
                                </div>
                                <div class=\"member--bio\">
                                    <h4>{{ member.full_name }}</h4>
                                    <p>{{ member.job }}</p>
                                </div>
                            </div>
                        </li>
                    {% endfor %}
                </ul>
            </div>
        {% endif %}
    </div>

    <!-- Blog -->
    {% include 'twig/blog/latest.twig' %}
    <!-- End blog -->

{% endblock %}", "twig\\pages\\about.twig", "D:\\xampp\\htdocs\\bookstore\\htdocs\\content\\themes\\bookstore\\resources\\views\\twig\\pages\\about.twig");
    }
}
