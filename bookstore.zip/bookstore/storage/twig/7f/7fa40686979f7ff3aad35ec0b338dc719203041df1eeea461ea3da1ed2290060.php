<?php

/* twig/layouts/main.twig */
class __TwigTemplate_359d41120dac07d50a84bef3b138269dfa8e412b5dcf3a7d4cce21d654afc04e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html class=\"no-js\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    ";
        // line 7
        echo twig_escape_filter($this->env, wp_head(), "html", null, true);
        echo "
</head>
<body>
<!--[if lt IE 8]>
<p class=\"browsehappy\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<header>
    <div id=\"bookstore-logo\">
        <a href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "home_url", array(), "method"), "html", null, true);
        echo "\">
            <img src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "themosis_theme_assets", array(), "method"), "html", null, true);
        echo "/images/logo.png\" alt=\"Bookstore\" width=\"154\" height=\"40\">
        </a>
    </div>
    <div id=\"bookstore-navigation\">
        ";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "wp_nav_menu", array(0 => array("theme_location" => "header-nav", "container" => false)), "method"), "html", null, true);
        // line 23
        echo "
    </div>
    <div id=\"bookstore-search\">
        <div id=\"search-button\"></div>
        <div id=\"search--form\">
            <div id=\"search--form__icon\"></div>
            <div id=\"search--form__form\">
                ";
        // line 30
        echo $this->getAttribute(($context["Form"] ?? null), "open", array(0 => $this->getAttribute(($context["fn"] ?? null), "home_url", array(), "method"), 1 => "get", 2 => false, 3 => array("class" => "searchform", "role" => "search")), "method");
        echo "
                ";
        // line 31
        echo $this->getAttribute(($context["Form"] ?? null), "text", array(0 => "s", 1 => "", 2 => array("id" => "s", "placeholder" => call_user_func_array($this->env->getFunction('__')->getCallable(), array("Search a book...", twig_constant("THEME_TEXTDOMAIN"))), "autocomplete" => "off")), "method");
        echo "
                ";
        // line 32
        echo $this->getAttribute(($context["Form"] ?? null), "close", array(), "method");
        echo "
            </div>
        </div>
    </div>
</header>

";
        // line 38
        $this->displayBlock('main', $context, $blocks);
        // line 39
        echo "
<footer>
    <div class=\"wrapper\">
        <div class=\"footer--copyright\">
            <p>&copy; ";
        // line 43
        echo twig_escape_filter($this->env, sprintf("%s %d", call_user_func_array($this->env->getFunction('__')->getCallable(), array("Copyright Bookstore", twig_constant("THEME_TEXTDOMAIN"))), twig_date_format_filter($this->env, "now", "Y")), "html", null, true);
        echo "</p>
        </div>
        <div class=\"footer--navigation\">
            ";
        // line 46
        echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "wp_nav_menu", array(0 => array("theme_location" => "footer-nav", "container" => false)), "method"), "html", null, true);
        // line 49
        echo "
        </div>
    </div>
</footer>
";
        // line 53
        echo twig_escape_filter($this->env, wp_footer(), "html", null, true);
        echo "
</body>
</html>";
    }

    // line 38
    public function block_main($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "twig/layouts/main.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 38,  100 => 53,  94 => 49,  92 => 46,  86 => 43,  80 => 39,  78 => 38,  69 => 32,  65 => 31,  61 => 30,  52 => 23,  50 => 20,  43 => 16,  39 => 15,  28 => 7,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html class=\"no-js\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    {{ wp_head() }}
</head>
<body>
<!--[if lt IE 8]>
<p class=\"browsehappy\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<header>
    <div id=\"bookstore-logo\">
        <a href=\"{{ fn.home_url() }}\">
            <img src=\"{{ fn.themosis_theme_assets() }}/images/logo.png\" alt=\"Bookstore\" width=\"154\" height=\"40\">
        </a>
    </div>
    <div id=\"bookstore-navigation\">
        {{ fn.wp_nav_menu({
            'theme_location': 'header-nav',
            'container': false
        }) }}
    </div>
    <div id=\"bookstore-search\">
        <div id=\"search-button\"></div>
        <div id=\"search--form\">
            <div id=\"search--form__icon\"></div>
            <div id=\"search--form__form\">
                {{ Form.open(fn.home_url(), 'get', false, {'class': 'searchform', 'role': 'search'})|raw }}
                {{ Form.text('s', '', {'id': 's', 'placeholder': __(\"Search a book...\", constant('THEME_TEXTDOMAIN')), 'autocomplete': 'off'})|raw }}
                {{ Form.close()|raw }}
            </div>
        </div>
    </div>
</header>

{% block main %}{% endblock %}

<footer>
    <div class=\"wrapper\">
        <div class=\"footer--copyright\">
            <p>&copy; {{ '%s %d'|format(__(\"Copyright Bookstore\", constant('THEME_TEXTDOMAIN')), \"now\"|date('Y')) }}</p>
        </div>
        <div class=\"footer--navigation\">
            {{ fn.wp_nav_menu({
                'theme_location': 'footer-nav',
                'container': false
            }) }}
        </div>
    </div>
</footer>
{{ wp_footer() }}
</body>
</html>", "twig/layouts/main.twig", "D:\\xampp\\htdocs\\bookstore\\htdocs\\content\\themes\\bookstore\\resources\\views\\twig\\layouts\\main.twig");
    }
}
