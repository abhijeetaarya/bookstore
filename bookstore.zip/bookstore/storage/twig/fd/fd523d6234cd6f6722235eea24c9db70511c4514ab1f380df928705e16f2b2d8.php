<?php

/* twig\pages\home.twig */
class __TwigTemplate_7a53b4b58f953336cebe0e02dc1bdf6c6bc913b2ffaf641a7dacdf34fd0d8d0b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("twig/layouts/main.twig", "twig\\pages\\home.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "twig/layouts/main.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
    <!-- Book Promo -->
    <div id=\"bks-promo\" style=\"background-color: ";
        // line 6
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('meta')->getCallable(), array("color", $this->getAttribute(($context["promo"] ?? null), "ID", array()))), "html", null, true);
        echo ";\">
        <div class=\"wrapper\">
            <div class=\"promo-wrapper\">
                <div class=\"promo-container\">
                    <h1>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["promo"] ?? null), "post_title", array()), "html", null, true);
        echo "</h1>
                    <h5>";
        // line 11
        echo twig_escape_filter($this->env, sprintf("%s %s", call_user_func_array($this->env->getFunction('__')->getCallable(), array("By", twig_constant("THEME_TEXTDOMAIN"))), call_user_func_array($this->env->getFunction('meta')->getCallable(), array("author", $this->getAttribute(($context["promo"] ?? null), "ID", array())))), "html", null, true);
        echo "</h5>
                    <a href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "get_permalink", array(0 => $this->getAttribute(($context["promo"] ?? null), "ID", array())), "method"), "html", null, true);
        echo "\" class=\"big-button\">";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("Buy book", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
        echo "</a>
                </div>
                <div class=\"promo-media\">
                    <img src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "wp_get_attachment_image_url", array(0 => call_user_func_array($this->env->getFunction('meta')->getCallable(), array("promo-image", $this->getAttribute(($context["promo"] ?? null), "ID", array()))), 1 => "book-promo"), "method"), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["promo"] ?? null), "post_title", array()), "html", null, true);
        echo "\" width=\"399\" height=\"435\">
                </div>
            </div>
        </div>
    </div>
    <!-- End Book Promo -->

    <!-- Popular -->
    <div id=\"popular-books\" class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>";
        // line 25
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("Popular", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
        echo "</h1>
            <a href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "get_post_type_archive_link", array(0 => $this->getAttribute(($context["promo"] ?? null), "post_type", array())), "method"), "html", null, true);
        echo "\" title=\"";
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("Books", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
        echo "\" class=\"bks-link\">";
        echo twig_escape_filter($this->env, sprintf("> %s", call_user_func_array($this->env->getFunction('__')->getCallable(), array("All Books", twig_constant("THEME_TEXTDOMAIN")))), "html", null, true);
        echo "</a>
        </div>
        <div id=\"popular-container\">
            <ul class=\"books\">
                ";
        // line 30
        $context["modulo"] = 3;
        // line 31
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["books"] ?? null));
        foreach ($context['_seq'] as $context["i"] => $context["book"]) {
            // line 32
            echo "                    ";
            if ((2 == ($context["i"] % ($context["modulo"] ?? null)))) {
                // line 33
                echo "                        <li class=\"last\">
                    ";
            } else {
                // line 35
                echo "                        <li>
                    ";
            }
            // line 37
            echo "                        <div class=\"book\">
                            <h3>";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "post_title", array()), "html", null, true);
            echo "</h3>
                            ";
            // line 39
            if ($this->getAttribute(($context["fn"] ?? null), "has_post_thumbnail", array(0 => $this->getAttribute($context["book"], "ID", array())), "method")) {
                // line 40
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "get_permalink", array(0 => $this->getAttribute($context["book"], "ID", array())), "method"), "html", null, true);
                echo "\" class=\"book-featured-box\" style=\"background-color: ";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('meta')->getCallable(), array("color", $this->getAttribute($context["book"], "ID", array()))), "html", null, true);
                echo ";\">
                                    ";
                // line 41
                echo $this->getAttribute(($context["fn"] ?? null), "get_the_post_thumbnail", array(0 => $this->getAttribute($context["book"], "ID", array()), 1 => "book-features-image"), "method");
                echo "
                                </a>
                            ";
            }
            // line 44
            echo "                            <p>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "post_excerpt", array()), "html", null, true);
            echo "</p>
                            <div class=\"button-box\">
                                <a href=\"";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "get_permalink", array(0 => $this->getAttribute($context["book"], "ID", array())), "method"), "html", null, true);
            echo "\" class=\"tiny-button\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("Buy", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
            echo "</a>
                            </div>
                        </div>
                    </li>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['i'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "            </ul>
        </div>
    </div>
    <!-- End Popular -->

    ";
        // line 56
        $this->loadTemplate("twig/blog/latest.twig", "twig\\pages\\home.twig", 56)->display($context);
        // line 57
        echo "
";
    }

    public function getTemplateName()
    {
        return "twig\\pages\\home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 57,  154 => 56,  147 => 51,  134 => 46,  128 => 44,  122 => 41,  115 => 40,  113 => 39,  109 => 38,  106 => 37,  102 => 35,  98 => 33,  95 => 32,  90 => 31,  88 => 30,  77 => 26,  73 => 25,  58 => 15,  50 => 12,  46 => 11,  42 => 10,  35 => 6,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'twig/layouts/main.twig' %}

{% block main %}

    <!-- Book Promo -->
    <div id=\"bks-promo\" style=\"background-color: {{ meta('color', promo.ID) }};\">
        <div class=\"wrapper\">
            <div class=\"promo-wrapper\">
                <div class=\"promo-container\">
                    <h1>{{ promo.post_title }}</h1>
                    <h5>{{ '%s %s'|format(__(\"By\", constant('THEME_TEXTDOMAIN')), meta('author', promo.ID)) }}</h5>
                    <a href=\"{{ fn.get_permalink(promo.ID) }}\" class=\"big-button\">{{ __(\"Buy book\", constant('THEME_TEXTDOMAIN')) }}</a>
                </div>
                <div class=\"promo-media\">
                    <img src=\"{{ fn.wp_get_attachment_image_url(meta('promo-image', promo.ID), 'book-promo') }}\" alt=\"{{ promo.post_title }}\" width=\"399\" height=\"435\">
                </div>
            </div>
        </div>
    </div>
    <!-- End Book Promo -->

    <!-- Popular -->
    <div id=\"popular-books\" class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>{{ __(\"Popular\", constant('THEME_TEXTDOMAIN')) }}</h1>
            <a href=\"{{ fn.get_post_type_archive_link(promo.post_type) }}\" title=\"{{ __(\"Books\", constant('THEME_TEXTDOMAIN')) }}\" class=\"bks-link\">{{ '> %s'|format(__(\"All Books\", constant('THEME_TEXTDOMAIN'))) }}</a>
        </div>
        <div id=\"popular-container\">
            <ul class=\"books\">
                {% set modulo = 3 %}
                {% for i, book in books %}
                    {% if 2 == i % modulo %}
                        <li class=\"last\">
                    {% else %}
                        <li>
                    {% endif %}
                        <div class=\"book\">
                            <h3>{{ book.post_title }}</h3>
                            {% if (fn.has_post_thumbnail(book.ID)) %}
                                <a href=\"{{ fn.get_permalink(book.ID) }}\" class=\"book-featured-box\" style=\"background-color: {{ meta('color', book.ID) }};\">
                                    {{ fn.get_the_post_thumbnail(book.ID, 'book-features-image')|raw }}
                                </a>
                            {% endif %}
                            <p>{{ book.post_excerpt }}</p>
                            <div class=\"button-box\">
                                <a href=\"{{ fn.get_permalink(book.ID) }}\" class=\"tiny-button\">{{ __(\"Buy\", constant('THEME_TEXTDOMAIN')) }}</a>
                            </div>
                        </div>
                    </li>
                {% endfor %}
            </ul>
        </div>
    </div>
    <!-- End Popular -->

    {% include 'twig/blog/latest.twig' %}

{% endblock %}", "twig\\pages\\home.twig", "D:\\xampp\\htdocs\\bookstore\\htdocs\\content\\themes\\bookstore\\resources\\views\\twig\\pages\\home.twig");
    }
}
