<?php

/* twig\books\archive.twig */
class __TwigTemplate_4e441de38a8cb71ddd8a10aacd6bdaf738d7c17f32e59a8bd004baa9ce368370 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("twig/layouts/main.twig", "twig\\books\\archive.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "twig/layouts/main.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
    <div id=\"books\" class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>";
        // line 7
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("Collection", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
        echo "</h1>
        </div>
        <div id=\"books--collection\">
            <ul class=\"books\">
            ";
        // line 11
        $context["modulo"] = 3;
        // line 12
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["books"] ?? null));
        foreach ($context['_seq'] as $context["i"] => $context["book"]) {
            // line 13
            echo "                ";
            if (((($context["modulo"] ?? null) - 1) == ($context["i"] % ($context["modulo"] ?? null)))) {
                // line 14
                echo "                    <li class=\"last\">
                ";
            } else {
                // line 16
                echo "                    <li>
                ";
            }
            // line 18
            echo "                        <div class=\"book\">
                            <h3>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "post_title", array()), "html", null, true);
            echo "</h3>
                            ";
            // line 20
            if ($this->getAttribute(($context["fn"] ?? null), "has_post_thumbnail", array(0 => $this->getAttribute($context["book"], "ID", array())), "method")) {
                // line 21
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "get_permalink", array(0 => $this->getAttribute($context["book"], "ID", array())), "method"), "html", null, true);
                echo "\" class=\"book-featured-box\" style=\"background-color: ";
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('meta')->getCallable(), array("color", $this->getAttribute($context["book"], "ID", array()))), "html", null, true);
                echo ";\">
                                    ";
                // line 22
                echo $this->getAttribute(($context["fn"] ?? null), "get_the_post_thumbnail", array(0 => $this->getAttribute($context["book"], "ID", array()), 1 => "book-features-image"), "method");
                echo "
                                </a>
                            ";
            }
            // line 25
            echo "                            <p>";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "get_the_excerpt", array(0 => $this->getAttribute($context["book"], "ID", array())), "method"), "html", null, true);
            echo "</p>
                            <div class=\"button-box\">
                                <a href=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute(($context["fn"] ?? null), "get_permalink", array(0 => $this->getAttribute($context["book"], "ID", array())), "method"), "html", null, true);
            echo "\" class=\"tiny-button\">";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('__')->getCallable(), array("Buy", twig_constant("THEME_TEXTDOMAIN"))), "html", null, true);
            echo "</a>
                            </div>
                        </div>
                    </li>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['i'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "            </ul>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "twig\\books\\archive.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 32,  89 => 27,  83 => 25,  77 => 22,  70 => 21,  68 => 20,  64 => 19,  61 => 18,  57 => 16,  53 => 14,  50 => 13,  45 => 12,  43 => 11,  36 => 7,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'twig/layouts/main.twig' %}

{% block main %}

    <div id=\"books\" class=\"wrapper\">
        <div class=\"bks-title-box\">
            <h1>{{ __(\"Collection\", constant('THEME_TEXTDOMAIN')) }}</h1>
        </div>
        <div id=\"books--collection\">
            <ul class=\"books\">
            {% set modulo = 3 %}
                {% for i, book in books %}
                {% if modulo - 1 == i % modulo %}
                    <li class=\"last\">
                {% else %}
                    <li>
                {% endif %}
                        <div class=\"book\">
                            <h3>{{ book.post_title }}</h3>
                            {% if fn.has_post_thumbnail(book.ID) %}
                                <a href=\"{{ fn.get_permalink(book.ID) }}\" class=\"book-featured-box\" style=\"background-color: {{ meta('color', book.ID) }};\">
                                    {{ fn.get_the_post_thumbnail(book.ID, 'book-features-image')|raw }}
                                </a>
                            {% endif %}
                            <p>{{ fn.get_the_excerpt(book.ID) }}</p>
                            <div class=\"button-box\">
                                <a href=\"{{ fn.get_permalink(book.ID) }}\" class=\"tiny-button\">{{ __(\"Buy\", constant('THEME_TEXTDOMAIN')) }}</a>
                            </div>
                        </div>
                    </li>
                {% endfor %}
            </ul>
        </div>
    </div>

{% endblock %}", "twig\\books\\archive.twig", "D:\\xampp\\htdocs\\bookstore\\htdocs\\content\\themes\\bookstore\\resources\\views\\twig\\books\\archive.twig");
    }
}
