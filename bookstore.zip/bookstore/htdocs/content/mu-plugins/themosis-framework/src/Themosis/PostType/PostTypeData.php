<?php

namespace Themosis\PostType;

use Themosis\Foundation\DataContainer;

class PostTypeData extends DataContainer
{
}
