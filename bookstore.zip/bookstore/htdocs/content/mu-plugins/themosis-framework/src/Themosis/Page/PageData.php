<?php

namespace Themosis\Page;

use Themosis\Foundation\DataContainer;

class PageData extends DataContainer
{
}
