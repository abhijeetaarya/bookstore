<?php

namespace Themosis\User;

use Exception;

class UserException extends Exception
{
}
