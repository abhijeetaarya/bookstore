<?php

namespace Themosis\Finder;

use Exception;

class FinderException extends Exception
{
}
