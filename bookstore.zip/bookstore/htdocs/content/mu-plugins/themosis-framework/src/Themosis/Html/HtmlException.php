<?php

namespace Themosis\Html;

use Exception;

class HtmlException extends Exception
{
}
