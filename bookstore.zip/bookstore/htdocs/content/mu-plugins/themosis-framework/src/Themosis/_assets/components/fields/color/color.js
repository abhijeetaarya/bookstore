import $ from 'jquery';

$('.themosis-color-field').wpColorPicker();