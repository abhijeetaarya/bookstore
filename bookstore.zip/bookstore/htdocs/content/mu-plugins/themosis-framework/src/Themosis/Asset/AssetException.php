<?php

namespace Themosis\Asset;

use Exception;

class AssetException extends Exception
{
}
