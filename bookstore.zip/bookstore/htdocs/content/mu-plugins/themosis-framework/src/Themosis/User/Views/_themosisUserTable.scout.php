<table class="form-table">
    <tbody>
        @each('_themosisUserRow', $__fields, 'field')
    </tbody>
</table>