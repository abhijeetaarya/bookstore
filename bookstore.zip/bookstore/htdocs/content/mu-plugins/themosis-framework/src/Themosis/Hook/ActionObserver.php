<?php

namespace Themosis\Hook;

interface ActionObserver
{
    /**
     * Trigger method.
     */
    public function update();
}
