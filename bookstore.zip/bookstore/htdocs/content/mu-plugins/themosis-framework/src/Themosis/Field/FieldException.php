<?php

namespace Themosis\Field;

use Exception;

class FieldException extends Exception
{
}
