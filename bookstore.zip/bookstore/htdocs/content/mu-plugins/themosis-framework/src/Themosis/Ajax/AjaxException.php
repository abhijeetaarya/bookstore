<?php

namespace Themosis\Ajax;

use Exception;

class AjaxException extends Exception
{
}
