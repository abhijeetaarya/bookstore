Bookstore Books
===============

Bookstore custom plugin in order to handle a collection of books.