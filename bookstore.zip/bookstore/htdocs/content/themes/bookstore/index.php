<?php

/**
 * Default WordPress template.
 *
 * In order to work on your templates, please use the `routes.php` file
 * located into the `resources` folder.
 */